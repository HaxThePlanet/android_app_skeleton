package com.example.skeleton.billing;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.skeleton.R;

public class inAppBilling extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in_app_billing);
    }
}
