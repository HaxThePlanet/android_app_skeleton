# android_app_skeleton
Basic Android app skeleton, splash, welcome and nav drawer etc
